"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[4886],{

/***/ 94886:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Windows_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/Icons/Windows.svg
var Windows_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="none"><g clip-path="url(%23a)"><path fill="%230078D4" d="M0 0h22.755v22.745H0V0Zm25.245 0H48v22.745H25.245V0ZM0 25.245h22.755V48H0V25.245Zm25.245 0H48V48H25.245"/></g><defs><clipPath id="a"><path fill="%23fff" d="M0 0h48v48H0z"/></clipPath></defs></svg>';



/***/ })

}]);