"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[1982],{

/***/ 1982:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ cronos_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/cronos.svg
var cronos_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="28" height="28"><defs><linearGradient id="A" x1="-18.275%" x2="84.959%" y1="8.219%" y2="71.393%"><stop offset="0%" stop-color="%23002d74"/><stop offset="100%" stop-color="%23001246"/></linearGradient><circle id="B" cx="14" cy="14" r="14"/></defs><g fill-rule="evenodd"><mask id="C" fill="%23fff"><use xlink:href="%23B"/></mask><g fill-rule="nonzero"><path fill="url(%23A)" d="M-1.326-1.326h30.651v30.651H-1.326z" mask="url(%23C)"/><g fill="%23fff"><path d="M14.187 6L7 10.175v8.35l7.187 4.175 7.175-4.175v-8.35L14.187 6zm5.046 11.286l-5.058 2.936-5.046-2.936v-5.871l5.058-2.936 5.046 2.936v5.871z"/><path d="M14.187 22.7l7.175-4.175v-8.35L14.187 6v2.479l5.046 2.936v5.883l-5.058 2.936V22.7h.012z"/><path d="M14.175 6L7 10.175v8.35l7.175 4.175v-2.479l-5.046-2.936v-5.883l5.046-2.924V6zm3.36 10.299l-3.348 1.949-3.36-1.949v-3.898l3.36-1.949 3.348 1.949-1.399.818-1.961-1.143-1.949 1.143v2.274l1.961 1.143 1.961-1.143 1.387.806z"/></g></g></g></svg>';



/***/ })

}]);