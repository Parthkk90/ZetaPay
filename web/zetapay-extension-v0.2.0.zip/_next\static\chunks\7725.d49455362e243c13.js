"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[7725],{

/***/ 87725:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ manta_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/manta.svg
var manta_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28"><g clip-path="url(%23a)"><path fill="%23F9F7EC" d="M14 28c7.732 0 14-6.268 14-14S21.732 0 14 0 0 6.268 0 14s6.268 14 14 14Z"/><g clip-path="url(%23b)"><mask id="c" width="28" height="28" x="0" y="0" maskUnits="userSpaceOnUse" style="mask-type:luminance"><path fill="%23fff" d="M28 0H0v28h28V0Z"/></mask><g mask="url(%23c)"><path fill="url(%23d)" fill-rule="evenodd" d="M6.51 24.04A12.508 12.508 0 0 1 1.473 14C1.474 7.082 7.082 1.474 14 1.474c5.71 0 11.945 3.412 13.453 8.637C25.768 4.272 20.383 0 14 0 6.268 0 0 6.268 0 14s6.268 14 14 14 14-6.268 14-14v-.737h-.77l-.102-.001c-.09-.002-.222-.004-.387-.01-.33-.011-.789-.034-1.303-.078-1.05-.092-2.248-.27-3.064-.596-1.313-.524-2.054-1.219-2.9-2.032l-.05-.047c-.848-.815-1.8-1.73-3.452-2.508-1.628-.766-3.427-.643-4.749-.37a12.04 12.04 0 0 0-2.138.656c-.665.28-1.31.611-1.964.919 0 0 1.281.351 1.915.547l.106.034a7.416 7.416 0 0 1 1.605.767c.683.44 1.25.992 1.482 1.671-1.451.19-2.812.828-3.83 1.426a15.679 15.679 0 0 0-1.91 1.33c-.084.068-1.394 1.222-1.394 1.222s1.69.18 2.524.348c.555.112 1.303.292 2.083.564.784.274 1.576.632 2.233 1.09.659.46 1.14.992 1.379 1.6.693 1.771.013 3.497-1.353 4.467-1.35.96-3.4 1.187-5.452-.221Zm4.776 2.192a5.647 5.647 0 0 0 1.529-.769c1.858-1.32 2.836-3.74 1.871-6.205-.379-.969-1.103-1.71-1.907-2.27-.806-.563-1.733-.975-2.591-1.274A16.895 16.895 0 0 0 8.6 15.25c.17-.11.352-.225.546-.339 1.134-.667 2.562-1.28 3.932-1.28 2.064 0 3.602.634 5.07 1.314l.402.188c1.312.615 2.69 1.262 4.291 1.262a7.463 7.463 0 0 0 3.595-.893C25.695 21.712 20.41 26.526 14 26.526c-.932 0-1.84-.101-2.714-.294Zm13.559-11.635a6.172 6.172 0 0 1-2.003.324c-1.256 0-2.335-.503-3.705-1.142l-.368-.171c-1.372-.636-2.959-1.309-5.024-1.43-.277-1.368-1.314-2.303-2.202-2.873a7.855 7.855 0 0 0-.295-.181c.088-.021.18-.041.272-.06 1.193-.246 2.618-.307 3.824.26 1.432.674 2.24 1.45 3.08 2.257l.029.028c.864.83 1.779 1.7 3.374 2.338.887.354 2.034.544 3.018.65Z" clip-rule="evenodd"/></g></g></g><defs><clipPath id="a"><path fill="%23fff" d="M0 0h28v28H0z"/></clipPath><clipPath id="b"><path fill="%23fff" d="M0 0h28v28H0z"/></clipPath><linearGradient id="d" x1="0" x2="28.502" y1="28" y2="27.479" gradientUnits="userSpaceOnUse"><stop stop-color="%2329CCB9"/><stop offset=".495" stop-color="%230091FF"/><stop offset="1" stop-color="%23FF66B7"/></linearGradient></defs></svg>';



/***/ })

}]);