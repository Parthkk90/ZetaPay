"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[707],{

/***/ 707:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ klaytn_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/klaytn.svg
var klaytn_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" style="enable-background:new 0 0 2500 2500" viewBox="0 0 2500 2500"><linearGradient id="a" x1="686.142" x2="1928.142" y1="130.185" y2="2300.185" gradientTransform="matrix(1 0 0 -1 0 2497.89)" gradientUnits="userSpaceOnUse"><stop offset="0" style="stop-color:%23850000"/><stop offset=".251" style="stop-color:%23c70158"/><stop offset=".482" style="stop-color:%23de1e41"/><stop offset=".639" style="stop-color:%23f63b2a"/><stop offset="1" style="stop-color:%23ff8700"/></linearGradient><path d="m2042 2206-789-798-800 804c159 106 408 287 792 289s692-189 796-294l1-1zm164-1756-800 798c268 267 532 537 797 806 415-530 377-1076 3-1605v1zM290 2042 983 197 11 1175c-50 285 98 647 279 867zm365-363c50-13 1152-1145 1389-1380C1921 135 1499-7 1288 0L655 1679z" style="fill-rule:evenodd;clip-rule:evenodd;fill:url(%23a)"/></svg>';



/***/ })

}]);