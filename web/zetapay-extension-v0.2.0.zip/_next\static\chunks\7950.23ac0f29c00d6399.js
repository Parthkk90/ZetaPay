"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[7950],{

/***/ 77950:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ base_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/base.svg
var base_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" fill-rule="evenodd"><path fill="%230052FF" fill-rule="nonzero" d="M14 28a14 14 0 1 0 0-28 14 14 0 0 0 0 28Z"/><path fill="%23FFF" d="M13.967 23.86c5.445 0 9.86-4.415 9.86-9.86 0-5.445-4.415-9.86-9.86-9.86-5.166 0-9.403 3.974-9.825 9.03h14.63v1.642H4.142c.413 5.065 4.654 9.047 9.826 9.047Z"/></g></svg>';



/***/ })

}]);