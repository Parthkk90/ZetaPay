"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[6578],{

/***/ 6578:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ flow_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/flow.svg
var flow_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle fill="%2300ef8b" cx="50" cy="50" r="50"/><rect fill="%23fff" x="57.82" y="42.18" width="14.12" height="14.12"/><path fill="%23fff" d="M43.71,61.59a5.3,5.3,0,1,1-5.3-5.3h5.3V42.18h-5.3A19.41,19.41,0,1,0,57.82,61.59v-5.3H43.71Z"/><path fill="%23fff" d="M63.12,35.12H79V21H63.12A19.43,19.43,0,0,0,43.71,40.41v1.77H57.82V40.41A5.3,5.3,0,0,1,63.12,35.12Z"/><polygon fill="%2316ff99" points="43.71 56.29 57.82 56.29 57.82 56.29 57.82 42.18 57.82 42.18 43.71 42.18 43.71 56.29"/></svg>';



/***/ })

}]);