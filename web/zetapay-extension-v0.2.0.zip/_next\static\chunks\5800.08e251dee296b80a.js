"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[5800],{

/***/ 5800:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ xdc_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/xdc.svg
var xdc_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28"><g clip-path="url(%23a)"><path fill="%23B7B5B1" d="M8 8h12v12H8z"/><path fill="%23B7B5B1" d="M28 12.667C24.786-5.97.448-2.363.011 12.667c1.4.728 2.285 1.176 2.285 1.176s-.74.448-2.296 1.434c2.8 18.278 26.723 15.624 28-.023-1.523-.93-2.352-1.422-2.352-1.422s.717-.336 2.352-1.165Zm-11.973 6.507-2.285-3.92-2.318 3.92-1.758-.123 3.304-5.566L9.99 8.68l1.792-.157 2.117 3.562 2.117-3.405 1.669.045-2.778 4.726 3.058 5.69-1.96.045.022-.012Z"/><path fill="%23244B81" d="M26.869 11.94C22.512-4.627 2.52-.147 1.154 11.94a249.514 249.514 0 0 1 3.404 1.926l-3.416 2.172c2.98 15.927 24.54 12.858 25.727-.022-2.173-1.366-3.461-2.162-3.461-2.162s2.934-1.635 3.46-1.915Zm-10.842 7.246-2.285-3.92-2.318 3.92-1.747-.124 3.304-5.566L10 8.691l1.793-.157 2.116 3.562 2.117-3.405 1.669.045-2.766 4.726 3.057 5.69-1.96.045v-.011Z"/></g><defs><clipPath id="a"><path fill="%23fff" d="M0 0h28v28H0z"/></clipPath></defs></svg>';



/***/ })

}]);