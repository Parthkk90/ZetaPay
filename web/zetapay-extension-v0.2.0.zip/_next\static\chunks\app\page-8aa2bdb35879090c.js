(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[1931],{

/***/ 15076:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31814));


/***/ }),

/***/ 31814:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ page; }
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(57437);
// EXTERNAL MODULE: ./node_modules/@rainbow-me/rainbowkit/dist/index.js
var dist = __webpack_require__(67872);
// EXTERNAL MODULE: ./node_modules/@zetachain/universalkit/dist/index.js
var universalkit_dist = __webpack_require__(8398);
// EXTERNAL MODULE: ./node_modules/next/dist/api/link.js
var api_link = __webpack_require__(27648);
// EXTERNAL MODULE: ./node_modules/next-themes/dist/index.mjs
var next_themes_dist = __webpack_require__(25922);
;// CONCATENATED MODULE: ./src/app/welcome.tsx



const Welcome = ()=>{
    const { theme } = (0,next_themes_dist/* useTheme */.F)();
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "w-full flex justify-center",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "max-w-6xl min-h-[686px] grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "order-2 md:order-1 flex items-center",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "mb-5 flex text-zeta-grey-800 dark:text-zeta-grey-50",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Logo, {})
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "flex gap-2 mb-[30px]",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                children: "from"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                                className: "text-zeta-green-700 dark:text-zeta-grey-50",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(ZetaChain, {})
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "text-zeta-grey-400 text-lg dark:text-zeta-grey-300 max-w-[448px]",
                                        children: "A robust ZetaChain component library of ready to use React components that lets you build user interfaces for universal apps."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "order-1 md:order-2 flex items-center",
                            children: theme === "dark" ? /*#__PURE__*/ (0,jsx_runtime.jsx)(HeroDark, {}) : /*#__PURE__*/ (0,jsx_runtime.jsx)(HeroLight, {})
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-8",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(api_link["default"], {
                            href: "https://zetachain.com/docs/developers/apps/intro",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "group dark:border-zeta-grey-600 hover:dark:border-transparent hover:dark:bg-zeta-grey-800 dark:shadow-none border border-zeta-grey-200 px-6 py-8 flex gap-4 rounded-lg hover:shadow-zeta-xl hover:border-transparent transition-all active:shadow-none active:border-zeta-grey-200",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "flex rounded-md overflow-hidden",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconCircles, {})
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "grow",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "dark:text-zeta-grey-50 text-2xl text-zeta-grey-600 font-medium leading-tight",
                                            children: "Get Started"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "leading-tight text-zeta-grey-400 dark:text-zeta-grey-300",
                                            children: "Learn about universal apps"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-end text-zeta-blue-700 dark:text-zeta-lime-700 dark:group-hover:text-zeta-mauve-700",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconArrow, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(api_link["default"], {
                            href: "https://www.zetachain.com/docs/developers/frontend/universalkit/",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "group dark:border-zeta-grey-600 hover:dark:border-transparent hover:dark:bg-zeta-grey-800 dark:shadow-none border border-zeta-grey-200 px-6 py-8 flex gap-4 rounded-lg hover:shadow-zeta-xl hover:border-transparent transition-all active:shadow-none active:border-zeta-grey-200",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "flex rounded-md overflow-hidden",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconDoc, {})
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "grow",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "dark:text-zeta-grey-50 text-2xl text-zeta-grey-600 font-medium leading-tight",
                                            children: "Documentation"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "leading-tight text-zeta-grey-400 dark:text-zeta-grey-300",
                                            children: "Explore components"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-end text-zeta-blue-700 dark:text-zeta-lime-700 dark:group-hover:text-zeta-mauve-700",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconArrow, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)(api_link["default"], {
                            href: "https://discord.com/invite/zetachain",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "group dark:border-zeta-grey-600 hover:dark:border-transparent hover:dark:bg-zeta-grey-800 dark:shadow-none border border-zeta-grey-200 px-6 py-8 flex gap-4 rounded-lg hover:shadow-zeta-xl hover:border-transparent transition-all active:shadow-none active:border-zeta-grey-200",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                        className: "flex rounded-md overflow-hidden",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconDiscord, {})
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "grow",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "dark:text-zeta-grey-50 text-2xl text-zeta-grey-600 font-medium leading-tight",
                                            children: "Discord"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                            className: "leading-tight text-zeta-grey-400 dark:text-zeta-grey-300",
                                            children: "Join a thriving community"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-end text-zeta-blue-700 dark:text-zeta-lime-700 dark:group-hover:text-zeta-mauve-700",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(IconArrow, {})
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
const HeroLight = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        width: "568",
        height: "320",
        viewBox: "0 0 568 320",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "21",
                y: "208.502",
                width: "144.948",
                height: "111.498",
                rx: "8.91986",
                fill: "#00946E"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M145.878 218.863L150.338 223.323L154.798 218.863L155.586 219.652L151.126 224.112L155.586 228.571L154.798 229.36L150.338 224.9L145.878 229.36L145.09 228.571L149.55 224.112L145.09 219.652L145.878 218.863Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "32.1498",
                y: "286.551",
                width: "122.648",
                height: "22.2997",
                rx: "4.45993",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "32.1498",
                y: "239.721",
                width: "122.648",
                height: "8.91986",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "32.1498",
                y: "253.101",
                width: "122.648",
                height: "8.91986",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "32.1498",
                y: "266.481",
                width: "66.899",
                height: "8.91986",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "390.059",
                width: "156.098",
                height: "49.0592",
                rx: "6.6899",
                fill: "#00A5C6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "414.589",
                cy: "24.5296",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M515.123 20.7567L521.627 27.2607L528.131 20.7567L529.117 21.7422L522.12 28.739C521.848 29.0111 521.407 29.0111 521.135 28.739L514.138 21.7422L515.123 20.7567Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M390.059 60.2091C390.059 56.5143 393.054 53.5192 396.749 53.5192H539.467C543.162 53.5192 546.157 56.5143 546.157 60.2091V98.1185H390.059V60.2091Z",
                fill: "#E5E8EC"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "414.589",
                cy: "78.0488",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#00B8DD"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                width: "156.098",
                height: "40.1394",
                transform: "translate(390.059 98.1185)",
                fill: "#A9ACB0",
                "fill-opacity": "0.5"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "414.589",
                cy: "118.188",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#C241B6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M390.059 138.258H546.157V176.167C546.157 179.862 543.162 182.857 539.467 182.857H396.749C393.054 182.857 390.059 179.862 390.059 176.167V138.258Z",
                fill: "#E5E8EC"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "414.589",
                cy: "158.328",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#00A87D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M514.624 126.128L531.453 137.976L523.183 140.953L516.47 146.626L514.624 126.128Z",
                fill: "#00A87D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "517.91",
                y: "134.294",
                width: "2.4715",
                height: "19.9205",
                transform: "rotate(-30 517.91 134.294)",
                fill: "#00A87D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M39.2997 19.2466C39.2997 15.3907 42.4256 12.2648 46.2815 12.2648H135.326V79.4835H46.2815C42.4256 79.4835 39.2997 76.3576 39.2997 72.5017V19.2466Z",
                fill: "#00D5FF"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "135.328",
                y: "34.3505",
                width: "5.7616",
                height: "23.0464",
                fill: "#E5E8EC"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M135.328 34.3504V57.3968H100.058C96.2017 57.3968 93.0758 54.271 93.0758 50.415V41.3323C93.0758 37.4763 96.2017 34.3504 100.058 34.3504H135.328Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "104.599",
                cy: "45.8738",
                r: "4.80134",
                fill: "#006579"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "17",
                y: "62.439",
                width: "45.4102",
                height: "32.4359",
                rx: "16.2179",
                fill: "#9AEA4A"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M41.0007 77.3596V70.2238L38.4058 70.2238L38.4058 77.3596H31.2699V79.9544H38.4058L38.4058 87.0905H41.0007V79.9544H48.1365V77.3596H41.0007Z",
                fill: "black"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "180.443",
                width: "187.317",
                height: "144.948",
                rx: "8.91986",
                fill: "#008462"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "224.334",
                y: "21.1847",
                width: "125.161",
                height: "9.06145",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "224.334",
                y: "34.7769",
                width: "125.161",
                height: "9.06145",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "206.777",
                cy: "32.5115",
                rx: "8.49511",
                ry: "8.49511",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M210.315 30.769L206.368 34.7163C206.113 34.9715 205.699 34.9715 205.444 34.7163L203.239 32.5116L204.163 31.5875L205.906 33.3301L209.391 29.8449L210.315 30.769Z",
                fill: "black"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "206.777",
                cy: "72.1555",
                rx: "8.49511",
                ry: "8.49511",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "224.335",
                y: "60.8286",
                width: "125.161",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "224.335",
                y: "74.4209",
                width: "56.6341",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "206.777",
                cy: "111.799",
                rx: "8.49511",
                ry: "8.49511",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "224.335",
                y: "100.473",
                width: "125.161",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "224.335",
                y: "114.065",
                width: "56.6341",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "21",
                y: "133.798",
                width: "222.997",
                height: "44.5993",
                rx: "22.2997",
                fill: "#00A5C6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M45.5295 146.899C41.6809 146.899 38.5609 150.019 38.5609 153.868C38.5609 157.716 41.6809 160.836 45.5295 160.836C49.3782 160.836 52.4982 157.716 52.4982 153.868C52.4982 150.019 49.3782 146.899 45.5295 146.899ZM36.8884 153.868C36.8884 149.095 40.7572 145.226 45.5295 145.226C50.3019 145.226 54.1707 149.095 54.1707 153.868C54.1707 155.953 53.4322 157.865 52.2025 159.358L58.977 166.132L57.7944 167.315L51.0199 160.541C49.5271 161.77 47.6146 162.509 45.5295 162.509C40.7572 162.509 36.8884 158.64 36.8884 153.868Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "83.4391",
                cy: "156.098",
                r: "4.45993",
                fill: "#00D5FF"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "101.279",
                cy: "156.098",
                r: "4.45993",
                fill: "#00D5FF"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "119.118",
                cy: "156.098",
                r: "4.45993",
                fill: "#00D5FF"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "136.958",
                cy: "156.098",
                r: "4.45993",
                fill: "#00D5FF"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "154.798",
                cy: "156.098",
                r: "4.45993",
                fill: "#00D5FF"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M188.247 265.366H366.645V313.31C366.645 317.005 363.649 320 359.955 320H194.937C191.242 320 188.247 317.005 188.247 313.31V265.366Z",
                fill: "#E5E8EC"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M188.247 215.192C188.247 211.497 191.242 208.502 194.937 208.502H359.955C363.649 208.502 366.645 211.497 366.645 215.192V263.136H188.247V215.192Z",
                fill: "#E5E8EC"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "252.916",
                y: "241.951",
                width: "44.5993",
                height: "44.5993",
                rx: "22.2997",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M278.922 275.515H272.259C271.622 275.515 271.106 275.002 271.106 274.368L271.106 267.742H273.413V271.599L283.767 261.301L285.398 262.924L275.044 273.221H278.922V275.515Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M278.397 260.913V254.286C278.397 253.653 277.88 253.139 277.243 253.139L270.58 253.139V255.434L274.459 255.434L264.104 265.731L265.736 267.353L276.09 257.056V260.913H278.397Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "326.505",
                y: "228.571",
                width: "26.7596",
                height: "15.6098",
                rx: "7.80488",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M213.892 226.341H204.972V246.411H213.892V226.341ZM225.042 226.341H216.122V246.411H225.042V226.341Z",
                fill: "#A9ACB0",
                "fill-opacity": "0.5"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M213.892 283.206H204.972V303.275H213.892V283.206ZM225.042 283.206H216.122V303.275H225.042V283.206Z",
                fill: "#A9ACB0",
                "fill-opacity": "0.5"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M241.013 144.948H189.362C184.436 144.948 180.443 140.954 180.443 136.028V133.798H221.697C229.951 133.798 237.158 138.282 241.013 144.948Z",
                fill: "#005741"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "363.584",
                y: "287.665",
                width: "166.504",
                height: "2.97329",
                fill: "#EFF1F4"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "363.584",
                y: "287.665",
                width: "139.744",
                height: "2.97329",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M357.636 274.286L372.503 289.152L357.636 304.019L342.77 289.152L357.636 274.286Z",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M417.103 274.286L431.969 289.152L417.103 304.019L402.236 289.152L417.103 274.286Z",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M476.197 274.286L491.063 289.152L476.197 304.019L461.33 289.152L476.197 274.286Z",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M535.291 274.286L550.157 289.152L535.291 304.019L520.424 289.152L535.291 274.286Z",
                fill: "#E5E8EC"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M437.915 216.307C434.631 216.307 431.969 218.969 431.969 222.253V247.526C431.969 250.81 434.631 253.473 437.915 253.473H469.135L476.568 260.906L484.001 253.473H515.221C518.505 253.473 521.167 250.81 521.167 247.526V222.253C521.167 218.969 518.505 216.307 515.221 216.307H437.915Z",
                fill: "#00B8DD"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M472.852 231.173H480.285V238.607H472.852V231.173ZM457.986 231.173H465.419V238.607H457.986V231.173ZM495.152 231.173H487.719V238.607H495.152V231.173Z",
                fill: "#B0FF61"
            })
        ]
    });
};
const HeroDark = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        width: "534",
        height: "320",
        viewBox: "0 0 534 320",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "4",
                y: "208.502",
                width: "144.948",
                height: "111.498",
                rx: "8.91986",
                fill: "#00946E"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M128.878 218.863L133.338 223.323L137.798 218.863L138.587 219.652L134.127 224.112L138.587 228.571L137.798 229.36L133.338 224.9L128.878 229.36L128.09 228.571L132.55 224.112L128.09 219.652L128.878 218.863Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "15.1499",
                y: "286.551",
                width: "122.648",
                height: "22.2997",
                rx: "4.45993",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "15.1499",
                y: "239.721",
                width: "122.648",
                height: "8.91986",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "15.1499",
                y: "253.101",
                width: "122.648",
                height: "8.91986",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "15.1499",
                y: "266.481",
                width: "66.899",
                height: "8.91986",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "373.059",
                width: "156.098",
                height: "49.0592",
                rx: "6.6899",
                fill: "#006579"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "397.589",
                cy: "24.5296",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M498.123 20.7566L504.627 27.2607L511.131 20.7566L512.117 21.7421L505.12 28.7389C504.848 29.0111 504.406 29.0111 504.134 28.7389L497.137 21.7421L498.123 20.7566Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M373.059 60.2091C373.059 56.5143 376.054 53.5192 379.749 53.5192H522.467C526.161 53.5192 529.157 56.5143 529.157 60.2091V98.1185H373.059V60.2091Z",
                fill: "#1F2328"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "397.589",
                cy: "78.0488",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#00A5C6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                width: "156.098",
                height: "40.1394",
                transform: "translate(373.059 98.1184)",
                fill: "#3C4146"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "397.589",
                cy: "118.188",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#C241B6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M373.059 138.258H529.157V176.167C529.157 179.862 526.161 182.857 522.467 182.857H379.749C376.054 182.857 373.059 179.862 373.059 176.167V138.258Z",
                fill: "#1F2328"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "397.589",
                cy: "158.327",
                rx: "11.1498",
                ry: "11.1498",
                fill: "#00A87D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M497.624 126.128L514.453 137.976L506.183 140.954L499.47 146.626L497.624 126.128Z",
                fill: "#00A87D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "500.91",
                y: "134.294",
                width: "2.4715",
                height: "19.9205",
                transform: "rotate(-30 500.91 134.294)",
                fill: "#00A87D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M22.2996 19.2466C22.2996 15.3906 25.4254 12.2648 29.2814 12.2648H118.326V79.4835H29.2814C25.4254 79.4835 22.2996 76.3576 22.2996 72.5016V19.2466Z",
                fill: "#00A5C6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "118.328",
                y: "34.3505",
                width: "5.7616",
                height: "23.0464",
                fill: "#696E75"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M118.327 34.3503V57.3968H83.0575C79.2016 57.3968 76.0757 54.2709 76.0757 50.4149V41.3322C76.0757 37.4762 79.2016 34.3503 83.0575 34.3503H118.327Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "87.5992",
                cy: "45.8737",
                r: "4.80134",
                fill: "#006579"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                y: "62.439",
                width: "45.4102",
                height: "32.4359",
                rx: "16.2179",
                fill: "#9AEA4A"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M24.0006 77.3595V70.2238L21.4057 70.2238L21.4057 77.3595H14.2698V79.9544H21.4057L21.4057 87.0904H24.0006V79.9544H31.1364V77.3595H24.0006Z",
                fill: "black"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "163.442",
                width: "187.317",
                height: "144.948",
                rx: "8.91986",
                fill: "#008462"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "207.334",
                y: "21.1847",
                width: "125.161",
                height: "9.06145",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "207.334",
                y: "34.777",
                width: "125.161",
                height: "9.06145",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "189.777",
                cy: "32.5115",
                rx: "8.49511",
                ry: "8.49511",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M193.315 30.769L189.368 34.7162C189.112 34.9714 188.699 34.9714 188.443 34.7162L186.239 32.5116L187.163 31.5874L188.906 33.33L192.391 29.8448L193.315 30.769Z",
                fill: "black"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "189.777",
                cy: "72.1555",
                rx: "8.49511",
                ry: "8.49511",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "207.335",
                y: "60.8286",
                width: "125.161",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "207.335",
                y: "74.4209",
                width: "56.6341",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "189.777",
                cy: "111.799",
                rx: "8.49511",
                ry: "8.49511",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "207.335",
                y: "100.473",
                width: "125.161",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "207.335",
                y: "114.065",
                width: "56.6341",
                height: "9.06145",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "4",
                y: "133.798",
                width: "222.997",
                height: "44.5993",
                rx: "22.2997",
                fill: "#006579"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M28.5298 146.899C24.6811 146.899 21.5611 150.019 21.5611 153.867C21.5611 157.716 24.6811 160.836 28.5298 160.836C32.3785 160.836 35.4984 157.716 35.4984 153.867C35.4984 150.019 32.3785 146.899 28.5298 146.899ZM19.8887 153.867C19.8887 149.095 23.7574 145.226 28.5298 145.226C33.3021 145.226 37.1709 149.095 37.1709 153.867C37.1709 155.952 36.4324 157.865 35.2028 159.358L41.9772 166.132L40.7946 167.315L34.0202 160.54C32.5274 161.77 30.6148 162.509 28.5298 162.509C23.7574 162.509 19.8887 158.64 19.8887 153.867Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "66.4389",
                cy: "156.098",
                r: "4.45993",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "84.2788",
                cy: "156.098",
                r: "4.45993",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "102.118",
                cy: "156.098",
                r: "4.45993",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "119.958",
                cy: "156.098",
                r: "4.45993",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("circle", {
                cx: "137.798",
                cy: "156.098",
                r: "4.45993",
                fill: "#00C6EE"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M171.247 265.366H349.645V313.31C349.645 317.005 346.649 320 342.955 320H177.937C174.242 320 171.247 317.005 171.247 313.31V265.366Z",
                fill: "#3C4146"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M171.247 215.192C171.247 211.497 174.242 208.502 177.937 208.502H342.955C346.649 208.502 349.645 211.497 349.645 215.192V263.136H171.247V215.192Z",
                fill: "#3C4146"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "235.917",
                y: "241.951",
                width: "44.5993",
                height: "44.5993",
                rx: "22.2997",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M261.922 275.515H255.259C254.622 275.515 254.106 275.002 254.106 274.368L254.106 267.742H256.413V271.599L266.767 261.301L268.398 262.924L258.044 273.221H261.922V275.515Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M261.397 260.913V254.286C261.397 253.653 260.88 253.139 260.243 253.139L253.58 253.139V255.434L257.459 255.434L247.104 265.731L248.736 267.353L259.09 257.056V260.913H261.397Z",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "309.505",
                y: "228.571",
                width: "26.7596",
                height: "15.6098",
                rx: "7.80488",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M196.892 226.341H187.972V246.411H196.892V226.341ZM208.042 226.341H199.122V246.411H208.042V226.341Z",
                fill: "#2D3237"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M196.892 283.206H187.972V303.275H196.892V283.206ZM208.042 283.206H199.122V303.275H208.042V283.206Z",
                fill: "#2D3237"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M224.013 144.948H172.362C167.436 144.948 163.442 140.954 163.442 136.028V133.798H204.697C212.951 133.798 220.157 138.282 224.013 144.948Z",
                fill: "#005741"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "346.584",
                y: "287.665",
                width: "166.504",
                height: "2.97329",
                fill: "#3C4146"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "346.584",
                y: "287.665",
                width: "139.744",
                height: "2.97329",
                fill: "#00B8DD"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M340.636 274.286L355.503 289.152L340.636 304.019L325.77 289.152L340.636 274.286Z",
                fill: "#00B8DD"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M400.103 274.286L414.969 289.152L400.103 304.019L385.236 289.152L400.103 274.286Z",
                fill: "#00B8DD"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M459.197 274.286L474.063 289.152L459.197 304.019L444.33 289.152L459.197 274.286Z",
                fill: "#00B8DD"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M518.291 274.286L533.157 289.152L518.291 304.019L503.424 289.152L518.291 274.286Z",
                fill: "#3C4146"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M420.915 216.307C417.631 216.307 414.969 218.969 414.969 222.253V247.526C414.969 250.81 417.631 253.473 420.915 253.473H452.135L459.568 260.906L467.001 253.473H498.221C501.505 253.473 504.167 250.81 504.167 247.526V222.253C504.167 218.969 501.505 216.307 498.221 216.307H420.915Z",
                fill: "#00A5C6"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M455.852 231.173H463.285V238.607H455.852V231.173ZM440.986 231.173H448.419V238.607H440.986V231.173ZM478.152 231.173H470.719V238.607H478.152V231.173Z",
                fill: "#B0FF61"
            })
        ]
    });
};
const Logo = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        width: "456",
        height: "65",
        viewBox: "0 0 456 65",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            d: "M25.096 64.704C10.664 64.704 0.896 56.696 0.896 41.736V2.4H11.808V41.824C11.808 50.272 17.264 54.496 25.096 54.496C32.928 54.496 38.384 50.272 38.384 41.824V2.4H49.208V41.736C49.208 56.696 39.44 64.704 25.096 64.704ZM57.821 64V19.648H68.645V26.512C71.021 21.672 76.125 18.944 82.461 18.944C92.405 18.944 98.917 26.16 98.917 36.544V64H88.181V38.832C88.181 32.76 84.397 28.536 78.853 28.536C72.869 28.536 68.645 33.288 68.645 39.8V64H57.821ZM107.624 64V19.648H118.448V64H107.624ZM107.272 12.696V0.639997H118.888V12.696H107.272ZM139.31 64L123.118 19.648H134.118L144.326 50.272L154.534 19.648H165.622L149.43 64H139.31ZM188.876 64.704C174.356 64.704 166.26 53.264 166.26 41.648C166.26 29.944 173.476 18.944 187.996 18.944C202.868 18.944 209.556 29.768 209.556 40.328C209.556 41.824 209.468 43.144 209.38 44.024H176.644C177.436 51.152 182.012 55.728 188.876 55.728C194.42 55.728 198.028 53.44 199.172 49.216H209.732C208.06 58.632 199.788 64.704 188.876 64.704ZM176.908 36.896H198.732C198.292 31.264 194.42 27.04 187.996 27.04C181.924 27.04 178.052 30.208 176.908 36.896ZM236.799 28.712C229.847 28.712 227.207 34.608 227.207 43.056V64H216.383V19.648H227.207V27.48C229.407 21.848 232.839 19.648 238.559 19.648H243.751V28.712H236.799ZM262.939 64.704C252.203 64.704 244.987 58.72 244.459 49.216H254.315C254.755 53.44 258.099 56.08 262.939 56.08C267.163 56.08 269.891 53.968 269.891 51.328C269.891 41.472 245.691 50.888 245.691 32.144C245.691 24.4 252.467 18.944 261.531 18.944C272.003 18.944 279.131 24.664 279.571 33.288H269.627C269.099 29.152 265.315 27.04 261.795 27.04C258.011 27.04 255.459 28.8 255.459 31.792C255.459 41.384 280.011 30.824 280.011 50.888C280.011 59.248 273.235 64.704 262.939 64.704ZM299.531 64.704C290.819 64.704 284.835 59.072 284.835 51.416C284.835 42.792 291.435 37.424 301.467 37.424H309.651C311.763 37.424 312.819 36.192 312.819 34.432C312.819 30.12 309.563 27.04 303.843 27.04C298.123 27.04 294.691 30.648 294.515 34.608H284.747C285.363 25.808 292.843 18.944 304.283 18.944C315.635 18.944 323.555 25.456 323.555 35.488V64H312.819V57.4C311.059 61.8 305.867 64.704 299.531 64.704ZM295.307 50.976C295.307 54.408 298.035 56.696 302.083 56.696C308.859 56.696 312.819 51.944 312.819 45.256V44.552H302.875C298.299 44.552 295.307 47.104 295.307 50.976ZM332.189 64V0.639997H343.013V64H332.189ZM364.325 64H352.709V2.4H364.325V29.328L389.141 2.4H403.573L380.957 26.864L405.949 64H391.429L372.949 35.488L364.325 44.816V64ZM408.59 64V19.648H419.414V64H408.59ZM408.238 12.696V0.639997H419.854V12.696H408.238ZM432.797 6.272H443.621V19.648H455.941V28.712H443.621V48.072C443.621 52.56 445.997 54.848 450.045 54.848H455.941V64H448.813C439.133 64 432.797 58.368 432.797 48.512V28.712H424.085V19.648H432.797V6.272Z",
            fill: "currentColor"
        })
    });
};
const ZetaChain = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        width: "130",
        height: "24",
        viewBox: "0 0 130 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            "fill-rule": "evenodd",
            "clip-rule": "evenodd",
            d: "M113.859 1.7763C113.859 1.34125 113.993 0.960424 114.263 0.633814C114.616 0.20522 115.164 -0.0336051 115.717 0.00383232C116.145 0.0335241 116.518 0.20651 116.836 0.525374C117.154 0.844238 117.328 1.21732 117.358 1.64592C117.395 2.19973 117.156 2.7458 116.729 3.09952C116.402 3.36933 116.02 3.50488 115.585 3.50488C115.101 3.50488 114.692 3.33835 114.359 3.00399C114.024 2.67093 113.858 2.2617 113.858 1.77759L113.859 1.7763ZM116.729 6.37077H114.492C114.48 6.37077 114.47 6.38059 114.47 6.39271V18.2514C114.47 18.2635 114.48 18.2733 114.492 18.2733H116.729C116.741 18.2733 116.751 18.2635 116.751 18.2514V6.39271C116.751 6.38059 116.741 6.37077 116.729 6.37077ZM127.675 18.2733H129.864L129.862 18.272H129.86V10.7638C129.86 8.6415 128.171 6.39783 125.466 6.36943H118.904C118.891 6.36943 118.882 6.37976 118.882 6.39138V18.2513C118.882 18.2642 118.893 18.2733 118.904 18.2733H121.072C121.085 18.2733 121.094 18.2629 121.094 18.2513V8.60406C121.094 8.59115 121.104 8.58211 121.116 8.58211H125.467C127.209 8.55888 127.687 8.83127 127.653 10.7638V18.2513C127.653 18.2642 127.663 18.2733 127.675 18.2733ZM112.331 6.39273V18.2527C112.331 18.2643 112.322 18.2746 112.309 18.2746H110.097C110.086 18.2746 110.075 18.2656 110.075 18.2527V16.2853C110.075 16.2633 110.047 16.2569 110.037 16.2762C109.653 16.9759 108.391 18.5625 105.907 18.5625C102.408 18.5625 99.7982 15.8063 99.7982 12.3233C99.7982 9.44453 101.861 6.05708 105.907 6.05708C108.361 6.05708 109.652 7.64495 110.037 8.34335C110.047 8.36271 110.075 8.35626 110.075 8.33431V6.39273C110.075 6.38111 110.084 6.37078 110.097 6.37078H112.309C112.32 6.37078 112.331 6.37982 112.331 6.39273ZM106.039 16.5176C108.713 16.5176 110.077 14.3398 110.077 12.3233C110.077 10.0797 108.485 8.10194 106.039 8.10194C103.157 8.10194 101.999 10.6374 102.053 12.3233C102.144 15.1738 104.102 16.5176 106.039 16.5176ZM89.5376 0.314975H87.2991L87.2978 0.313684C87.2849 0.313684 87.2759 0.324012 87.2759 0.335631V18.2527C87.2759 18.2656 87.2862 18.2746 87.2978 18.2746H89.5363C89.5493 18.2746 89.5583 18.2643 89.5583 18.2527V12.1388C89.5583 9.3813 91.1849 8.07486 92.9406 8.07486C95.2656 8.07486 95.9562 9.90929 95.9562 11.9554V18.2527C95.9562 18.2656 95.9666 18.2746 95.9782 18.2746H98.2167C98.2296 18.2746 98.2386 18.2643 98.2386 18.2527V11.248C98.2993 8.90881 97.5209 6.05711 93.7552 6.05711C91.0339 6.05711 89.9495 7.69274 89.5996 8.38856C89.5893 8.40792 89.5596 8.40147 89.5596 8.37952V0.336921C89.5596 0.324011 89.5493 0.314975 89.5376 0.314975ZM83.1192 10.6967C83.1088 10.6967 83.1011 10.689 83.0985 10.6787C82.9036 9.69626 82.5344 8.10194 79.7975 8.10194C77.6055 8.10194 76.1003 9.74532 76.1003 12.3233C76.1003 14.2146 77.0117 16.5176 79.9279 16.5176C82.1084 16.5176 82.7474 15.472 83.1217 14.2004C83.1243 14.1913 83.1321 14.1849 83.1424 14.1849H85.3822C85.3951 14.1849 85.4054 14.1965 85.4041 14.2094C85.1137 16.2168 83.6058 18.5625 79.7704 18.5625C76.1764 18.5625 73.8192 15.8799 73.8192 12.3233C73.8192 9.17601 75.8085 6.05708 79.7446 6.05708C83.9415 6.05708 85.2505 8.92299 85.3796 10.6735C85.3796 10.6864 85.3706 10.6967 85.3577 10.6967H83.1192ZM72.0363 18.2527V6.39273C72.0363 6.37982 72.026 6.37078 72.0144 6.37078H69.803C69.7901 6.37078 69.781 6.38111 69.781 6.39273V8.33431C69.781 8.35626 69.7526 8.36271 69.7423 8.34335C69.2853 7.43323 67.8472 6.05708 65.6126 6.05708C61.6661 6.05708 59.5038 9.28574 59.5038 12.3233C59.5038 16.0645 62.4304 18.5625 65.6126 18.5625C68.0021 18.5625 69.3421 17.0676 69.7423 16.2762C69.7513 16.2556 69.781 16.2633 69.781 16.2853V18.2527C69.781 18.2656 69.7914 18.2746 69.803 18.2746H72.0144C72.0273 18.2746 72.0363 18.2643 72.0363 18.2527ZM69.7823 12.3233C69.7823 14.2507 68.5508 16.5176 65.7442 16.5176C62.8925 16.5176 61.7591 14.1681 61.7591 12.3233C61.7591 10.4786 62.9584 8.10194 65.7442 8.10194C68.2061 8.10194 69.7823 10.09 69.7823 12.3233ZM59.2351 18.2552C59.2351 18.2655 59.2273 18.2745 59.217 18.2758C58.9924 18.3094 58.6968 18.3443 58.3301 18.3778C57.9545 18.4127 57.5736 18.4308 57.1902 18.4308C55.237 18.4308 53.4413 17.7298 53.4413 14.2623V8.30585C53.4413 8.29424 53.4323 8.28391 53.4194 8.28391H51.2596C51.248 8.28391 51.2377 8.27487 51.2377 8.26196V6.39138C51.2377 6.37976 51.2467 6.36943 51.2596 6.36943H53.4194C53.431 6.36943 53.4413 6.3604 53.4413 6.34749V2.37912C53.4413 2.3675 53.4503 2.35717 53.4633 2.35717H55.7018C55.7134 2.35717 55.7237 2.36621 55.7237 2.37912V6.34749C55.7237 6.35911 55.7327 6.36943 55.7457 6.36943H58.7962C58.8078 6.36943 58.8181 6.37847 58.8181 6.39138V8.26196C58.8181 8.27358 58.8091 8.28391 58.7962 8.28391H55.7457C55.734 8.28391 55.7237 8.29294 55.7237 8.30585V13.7459C55.7237 16.2465 56.7461 16.333 57.6898 16.333H58.516C58.8065 16.333 59.0389 16.3097 59.2106 16.262C59.2235 16.2581 59.2364 16.2684 59.2364 16.2826V18.2552H59.2351ZM41.708 12.9481C41.708 12.9352 41.7184 12.9249 41.73 12.9249V12.9236H50.7085C50.7188 12.9236 50.7279 12.9159 50.7292 12.9055C50.7795 12.5815 50.8092 12.2988 50.8182 12.0587C50.8273 11.8147 50.8312 11.6043 50.8312 11.43C50.8312 8.43627 48.4739 6.05576 45.3253 6.05576C41.9481 6.05576 39.4527 8.35881 39.4527 12.322C39.4527 15.561 41.4111 18.5612 45.404 18.5612C49.3969 18.5612 50.582 15.5545 50.7201 14.7864C50.7227 14.7735 50.7137 14.7606 50.6995 14.7606H48.4339C48.4248 14.7606 48.4184 14.7658 48.4145 14.7735C48.403 14.7987 48.3905 14.8277 48.3765 14.86L48.3765 14.86C48.1607 15.3591 47.6033 16.648 45.404 16.648C42.369 16.648 41.779 14.363 41.708 12.9481ZM41.7351 11.1718C41.7351 9.93893 42.4206 7.81274 45.2736 7.81274C47.7884 7.81274 48.7101 9.80983 48.6301 11.1731C48.6288 11.1847 48.6198 11.195 48.6081 11.195H41.7571C41.7442 11.195 41.7351 11.1834 41.7351 11.1718ZM31.4852 12.2394C29.47 14.0609 29.3099 15.5287 29.3099 17.2573V18.2733H38.548V16.24H31.3574C31.4632 15.3467 31.7976 14.6805 32.8045 13.7678L38.548 8.92809V6.36039H29.3022V8.39363H36.0642L31.511 12.2148L31.4852 12.2381V12.2394ZM16.7903 17.2241V17.2228L16.789 17.2241H16.7903ZM16.7903 20.4134V17.2241H20.3708V24H0V22.208C0 18.7108 0.329918 15.7426 4.47952 12.0652L4.50318 12.0428L14.4047 3.58536H3.58441V6.83781H0.00394324V3.05198e-05H20.3721V13.7177H16.7903V6.26153L6.84021 14.7584C4.49924 16.836 3.82231 18.3135 3.64093 20.4134H16.7903Z",
            fill: "currentColor"
        })
    });
};
const IconCircles = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        width: "48",
        height: "48",
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                y: "0.00012207",
                width: "48.0002",
                height: "48",
                fill: "#006579"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "17.2002",
                cy: "23.9999",
                rx: "10",
                ry: "10",
                fill: "#B0FF61"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("ellipse", {
                cx: "30.8002",
                cy: "23.9999",
                rx: "10",
                ry: "10",
                fill: "#00BC8D"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M24.0001 31.3319C25.9684 29.5057 27.2002 26.8965 27.2002 23.9997C27.2002 21.1029 25.9684 18.4938 24.0001 16.6675C22.0318 18.4938 20.8 21.1029 20.8 23.9997C20.8 26.8965 22.0318 29.5057 24.0001 31.3319Z",
                fill: "#00D5FF"
            })
        ]
    });
};
const IconArrow = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        width: "34",
        height: "34",
        viewBox: "0 0 34 34",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            "fill-rule": "evenodd",
            "clip-rule": "evenodd",
            d: "M23.3934 9.9155C23.8076 9.9155 24.1434 10.2513 24.1434 10.6655L24.1434 21.315H22.6434L22.6434 12.4762L10.6655 24.4541L9.60483 23.3934L21.5828 11.4155H12.7439L12.7439 9.9155L23.3934 9.9155Z",
            fill: "currentColor"
        })
    });
};
const IconDoc = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        width: "48",
        height: "48",
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                width: "48",
                height: "48",
                rx: "6",
                fill: "#9AEA4A"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M30.0328 8H10.6229C10.0435 8 9.57373 8.46974 9.57373 9.04918V38.9508C9.57373 39.5303 10.0435 40 10.6229 40H37.3771C37.9566 40 38.4263 39.5303 38.4263 38.9508V16.5333L30.0328 8Z",
                fill: "#006579"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "13.7703",
                y: "20.0656",
                width: "20.9837",
                height: "3.14754",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "13.7703",
                y: "26.3607",
                width: "20.9837",
                height: "3.14754",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                x: "13.7703",
                y: "32.6558",
                width: "20.9837",
                height: "3.14754",
                fill: "white"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M30.0328 16.5328L30.0328 8L38.4263 16.5328L30.0328 16.5328Z",
                fill: "white"
            })
        ]
    });
};
const IconDiscord = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        width: "48",
        height: "48",
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("rect", {
                width: "48",
                height: "48",
                rx: "6",
                fill: "#00946E"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                d: "M34.1783 15.1036C32.3638 14.2755 30.4065 13.6759 28.3635 13.3333C28.3206 13.3333 28.292 13.3476 28.2635 13.3761C28.0063 13.8187 27.7348 14.3898 27.5348 14.8323C25.3346 14.504 23.1487 14.504 21.0057 14.8323C20.8199 14.3755 20.5342 13.8187 20.277 13.3761C20.2628 13.3476 20.2199 13.3333 20.1913 13.3333C18.1483 13.6759 16.191 14.2898 14.3765 15.1036C14.3622 15.1036 14.348 15.1178 14.3337 15.1321C10.6333 20.5714 9.61896 25.8822 10.119 31.1215C10.119 31.1501 10.1333 31.1786 10.1619 31.1929C12.5907 32.9632 14.9623 34.0339 17.2768 34.7477C17.3196 34.762 17.3482 34.7477 17.3768 34.7192C17.9197 33.9768 18.4197 33.2059 18.8341 32.3779C18.8626 32.335 18.8341 32.2779 18.7912 32.2494C18.0197 31.9638 17.2768 31.6069 16.5624 31.2072C16.5053 31.1786 16.5053 31.093 16.5481 31.0644C16.691 30.9502 16.8482 30.836 16.991 30.7218C17.0196 30.7075 17.0482 30.6933 17.0768 30.7075C21.7486 32.8061 26.8205 32.8061 31.4352 30.7075C31.4637 30.6933 31.5066 30.6933 31.5352 30.7218C31.678 30.836 31.8209 30.9502 31.9781 31.0644C32.0352 31.1073 32.0209 31.1786 31.9638 31.2072C31.2494 31.6212 30.5065 31.9638 29.735 32.2494C29.6779 32.2636 29.6636 32.3207 29.6922 32.3779C30.1208 33.1916 30.6065 33.9768 31.1494 34.7049C31.178 34.7334 31.2066 34.7477 31.2494 34.7334C33.5782 34.0196 35.9498 32.9489 38.3929 31.1929C38.4072 31.1786 38.4215 31.1501 38.4358 31.1215C39.0358 25.0541 37.4357 19.8005 34.2068 15.1321C34.2068 15.1321 34.1926 15.1178 34.1783 15.1036ZM19.5341 27.9379C18.1197 27.9379 16.9625 26.6673 16.9625 25.1112C16.9625 23.5551 18.1054 22.2845 19.5341 22.2845C20.9771 22.2845 22.1201 23.5694 22.1058 25.1112C22.1058 26.6673 20.9628 27.9379 19.5341 27.9379ZM29.035 27.9379C27.6205 27.9379 26.4633 26.6673 26.4633 25.1112C26.4633 23.5551 27.6063 22.2845 29.035 22.2845C30.4779 22.2845 31.6209 23.5694 31.6066 25.1112C31.6066 26.6673 30.4779 27.9379 29.035 27.9379Z",
                fill: "#B0FF61"
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(2265);
// EXTERNAL MODULE: ./node_modules/wagmi/dist/esm/hooks/useAccount.js + 1 modules
var useAccount = __webpack_require__(64707);
// EXTERNAL MODULE: ./node_modules/wagmi/dist/esm/hooks/useChainId.js + 2 modules
var useChainId = __webpack_require__(44005);
// EXTERNAL MODULE: ./node_modules/wagmi/dist/esm/hooks/useSwitchChain.js + 5 modules
var useSwitchChain = __webpack_require__(59233);
// EXTERNAL MODULE: ./node_modules/wagmi/dist/esm/hooks/useWaitForTransactionReceipt.js + 2 modules
var useWaitForTransactionReceipt = __webpack_require__(97269);
// EXTERNAL MODULE: ./node_modules/wagmi/dist/esm/hooks/useWriteContract.js + 6 modules
var useWriteContract = __webpack_require__(33348);
// EXTERNAL MODULE: ./node_modules/viem/_esm/utils/unit/parseUnits.js
var parseUnits = __webpack_require__(68768);
;// CONCATENATED MODULE: ./src/UniversalPayment.abi.json
var UniversalPayment_abi_namespaceObject = /*#__PURE__*/JSON.parse('[{"inputs":[{"internalType":"address","name":"gatewayAddress","type":"address"},{"internalType":"address","name":"systemContractAddress","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[],"name":"CantBeIdenticalAddresses","type":"error"},{"inputs":[],"name":"CantBeZeroAddress","type":"error"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":false,"internalType":"string","name":"reason","type":"string"}],"name":"PaymentFailed","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"sender","type":"address"},{"indexed":true,"internalType":"address","name":"recipient","type":"address"},{"indexed":false,"internalType":"address","name":"inputToken","type":"address"},{"indexed":false,"internalType":"address","name":"targetToken","type":"address"},{"indexed":false,"internalType":"uint256","name":"inputAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"outputAmount","type":"uint256"}],"name":"PaymentProcessed","type":"event"},{"inputs":[{"internalType":"address","name":"token","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"emergencyWithdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"gateway","outputs":[{"internalType":"contract IGatewayZEVM","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"inputToken","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address","name":"targetToken","type":"address"},{"internalType":"address","name":"recipient","type":"address"}],"name":"processPayment","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"systemContract","outputs":[{"internalType":"contract SystemContract","name":"","type":"address"}],"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./src/app/Payment.tsx
/* provided dependency */ var process = __webpack_require__(25566);
/* __next_internal_client_entry_do_not_use__ Payment auto */ 





const UNIVERSAL_PAYMENT_ADDRESS = process.env.NEXT_PUBLIC_UNIVERSAL_PAYMENT_ADDRESS || "0x7a9cEdD3df8694Ef06B81A1E22Fb324353E35B01";
const ZETA_ATHENS_CHAIN_ID = 7001;
// Token addresses on ZetaChain Athens testnet (examples - replace with actual ZRC20 addresses)
const TOKENS = [
    {
        symbol: "ZETA",
        address: "0x0000000000000000000000000000000000000000",
        decimals: 18
    },
    {
        symbol: "ETH.ETH",
        address: "0x5F0b1a82749cb4E2278EC87F8BF6B618dC71a8bf",
        decimals: 18
    },
    {
        symbol: "BTC.BTC",
        address: "0x13A0c5930C028511Dc02665E7285134B6d11A5f4",
        decimals: 8
    }
];
const Payment = ()=>{
    const { address, isConnected } = (0,useAccount/* useAccount */.m)();
    const chainId = (0,useChainId/* useChainId */.x)();
    const { switchChain } = (0,useSwitchChain/* useSwitchChain */.o)();
    const [recipient, setRecipient] = (0,react.useState)("");
    const [amount, setAmount] = (0,react.useState)("");
    const [inputToken, setInputToken] = (0,react.useState)(TOKENS[0].address);
    const [targetToken, setTargetToken] = (0,react.useState)(TOKENS[0].address);
    const [status, setStatus] = (0,react.useState)(null);
    const [txHash, setTxHash] = (0,react.useState)(undefined);
    const { data: txReceipt, isLoading: isTxPending } = (0,useWaitForTransactionReceipt/* useWaitForTransactionReceipt */.A)({
        hash: txHash
    });
    const { writeContractAsync } = (0,useWriteContract/* useWriteContract */.S)();
    const handleSend = (0,react.useCallback)(async ()=>{
        if (!isConnected) return setStatus("Please connect your wallet first.");
        if (chainId !== ZETA_ATHENS_CHAIN_ID) {
            if (switchChain) {
                switchChain({
                    chainId: ZETA_ATHENS_CHAIN_ID
                });
            }
            return setStatus("Please switch to ZetaChain Athens testnet.");
        }
        if (!recipient) return setStatus("Recipient address required");
        if (!amount) return setStatus("Amount required");
        try {
            setStatus("Preparing transaction...");
            const selectedToken = TOKENS.find((t)=>t.address === inputToken);
            const weiAmount = (0,parseUnits/* parseUnits */.v)(amount, (selectedToken === null || selectedToken === void 0 ? void 0 : selectedToken.decimals) || 18);
            const hash = await writeContractAsync({
                address: UNIVERSAL_PAYMENT_ADDRESS,
                abi: UniversalPayment_abi_namespaceObject,
                functionName: "processPayment",
                args: [
                    inputToken,
                    weiAmount,
                    targetToken,
                    recipient
                ]
            });
            setTxHash(hash);
            setStatus("Transaction submitted: ".concat(hash));
        } catch (err) {
            var _err_message;
            setStatus("Failed: ".concat((_err_message = err === null || err === void 0 ? void 0 : err.message) !== null && _err_message !== void 0 ? _err_message : String(err)));
            setTxHash(undefined);
        }
    }, [
        isConnected,
        chainId,
        switchChain,
        recipient,
        amount,
        inputToken,
        targetToken,
        writeContractAsync
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md dark:bg-zeta-grey-800",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                        className: "text-2xl font-bold text-gray-900 dark:text-white",
                        children: "Send Payment"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(dist/* ConnectButton */.NL, {})
                ]
            }),
            chainId !== ZETA_ATHENS_CHAIN_ID && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "p-3 bg-yellow-100 dark:bg-yellow-900 rounded-md text-sm text-yellow-800 dark:text-yellow-200",
                children: "Please switch to ZetaChain Athens testnet"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                        htmlFor: "inputToken",
                        className: "block text-sm font-medium text-gray-700 dark:text-gray-300",
                        children: "Input Token"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("select", {
                        name: "inputToken",
                        id: "inputToken",
                        value: inputToken,
                        onChange: (e)=>setInputToken(e.target.value),
                        className: "block w-full px-3 py-2 mt-1 text-gray-900 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-zeta-grey-700 dark:border-zeta-grey-600 dark:text-white",
                        children: TOKENS.map((token)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: token.address,
                                children: token.symbol
                            }, token.address))
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                        htmlFor: "amount",
                        className: "block text-sm font-medium text-gray-700 dark:text-gray-300",
                        children: "Amount"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                        type: "text",
                        name: "amount",
                        id: "amount",
                        value: amount,
                        onChange: (e)=>setAmount(e.target.value),
                        className: "block w-full px-3 py-2 mt-1 text-gray-900 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-zeta-grey-700 dark:border-zeta-grey-600 dark:text-white",
                        placeholder: "0.0"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                        htmlFor: "targetToken",
                        className: "block text-sm font-medium text-gray-700 dark:text-gray-300",
                        children: "Target Token"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("select", {
                        name: "targetToken",
                        id: "targetToken",
                        value: targetToken,
                        onChange: (e)=>setTargetToken(e.target.value),
                        className: "block w-full px-3 py-2 mt-1 text-gray-900 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-zeta-grey-700 dark:border-zeta-grey-600 dark:text-white",
                        children: TOKENS.map((token)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("option", {
                                value: token.address,
                                children: token.symbol
                            }, token.address))
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("label", {
                        htmlFor: "recipient",
                        className: "block text-sm font-medium text-gray-700 dark:text-gray-300",
                        children: "Recipient Address"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                        type: "text",
                        name: "recipient",
                        id: "recipient",
                        value: recipient,
                        onChange: (e)=>setRecipient(e.target.value),
                        className: "block w-full px-3 py-2 mt-1 text-gray-900 bg-gray-100 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-zeta-grey-700 dark:border-zeta-grey-600 dark:text-white",
                        placeholder: "0x..."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                onClick: handleSend,
                disabled: !isConnected || isTxPending || chainId !== ZETA_ATHENS_CHAIN_ID,
                className: "w-full px-4 py-2 font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed dark:bg-zeta-blue-700 dark:hover:bg-zeta-blue-800",
                children: isTxPending ? "Processing..." : "Send Payment"
            }),
            status && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "pt-2 text-sm text-gray-700 dark:text-gray-300",
                children: [
                    status,
                    txReceipt && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "mt-1 text-green-600 dark:text-green-400",
                        children: "✓ Confirmed"
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/app/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Page = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "m-4",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex justify-end gap-2 mb-10",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(universalkit_dist/* ConnectBitcoin */.rp, {}),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(dist/* ConnectButton */.NL, {
                        label: "Connect EVM",
                        showBalance: false
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(Welcome, {}),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex justify-center mt-10",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Payment, {})
            })
        ]
    });
};
/* harmony default export */ var page = (Page);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [9818,9472,9136,9891,2971,2117,1744], function() { return __webpack_exec__(15076); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);