"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[1511],{

/***/ 81511:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ zkSync_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/zkSync.svg
var zkSync_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28"><g clip-path="url(%23a)"><path fill="%23F9F7EC" d="M14 28c7.732 0 14-6.268 14-14S21.732 0 14 0 0 6.268 0 14s6.268 14 14 14Z"/><path fill="%23000" fill-rule="evenodd" d="m22.12 13.93-4.669-4.648v3.402l-4.634 3.409h4.634v2.485l4.669-4.648ZM5.67 13.93l4.669 4.648v-3.381l4.634-3.437h-4.634V9.275L5.67 13.93Z" clip-rule="evenodd"/></g><defs><clipPath id="a"><path fill="%23fff" d="M0 0h28v28H0z"/></clipPath></defs></svg>';



/***/ })

}]);