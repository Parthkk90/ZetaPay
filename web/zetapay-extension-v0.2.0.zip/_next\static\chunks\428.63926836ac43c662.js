"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[428],{

/***/ 30428:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ gnosis_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/gnosis.svg
var gnosis_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path style="stroke:none;fill-rule:nonzero;fill:%2304795b;fill-opacity:1" d="M14 0c7.73 0 14 6.27 14 14s-6.27 14-14 14S0 21.73 0 14 6.27 0 14 0Zm0 0"/><path style="stroke:none;fill-rule:nonzero;fill:%23efefef;fill-opacity:1" d="M10.195 15.27c.551 0 1.063-.184 1.473-.504l-3.367-3.364c-.317.403-.5.91-.5 1.47a2.388 2.388 0 0 0 2.394 2.398ZM20.207 12.867c0-.555-.184-1.062-.504-1.472l-3.363 3.363c.402.32.91.504 1.469.504a2.388 2.388 0 0 0 2.398-2.395Zm0 0"/><path style="stroke:none;fill-rule:nonzero;fill:%23efefef;fill-opacity:1" d="m21.902 9.21-1.492 1.493c.496.594.793 1.344.793 2.176a3.394 3.394 0 0 1-3.394 3.394 3.381 3.381 0 0 1-2.176-.793L14 17.113l-1.633-1.633a3.393 3.393 0 0 1-4.781-4.777l-.762-.762-.726-.73a9.153 9.153 0 0 0-1.336 4.785 9.228 9.228 0 0 0 9.23 9.23c5.098 0 9.235-4.136 9.235-9.23a9.053 9.053 0 0 0-1.325-4.785Zm0 0"/><path style="stroke:none;fill-rule:nonzero;fill:%23efefef;fill-opacity:1" d="M20.68 7.621A9.209 9.209 0 0 0 14 4.761c-2.629 0-5 1.102-6.68 2.86-.226.242-.445.496-.652.758l7.324 7.32 7.324-7.328a6.291 6.291 0 0 0-.636-.75ZM14 5.961a7.91 7.91 0 0 1 5.676 2.355L14 13.988 8.324 8.316A7.923 7.923 0 0 1 14 5.961Zm0 0"/></svg>';



/***/ })

}]);