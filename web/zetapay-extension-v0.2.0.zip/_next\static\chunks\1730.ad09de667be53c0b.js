"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[1730],{

/***/ 61730:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Chrome_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/Icons/Chrome.svg
var Chrome_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 78 78"><path fill="url(%23a)" d="M71.034 20.5a37.001 37.001 0 0 0-64.084 0l2.22 39.96L71.034 20.5Z"/><path fill="url(%23b)" d="M22.979 48.25 6.958 20.5A37 37 0 0 0 39 76l36.26-37-52.281 9.25Z"/><path fill="url(%23c)" d="M55.021 48.25 39 76a37.001 37.001 0 0 0 32.035-55.5H39l16.021 27.75Z"/><path fill="%23fff" d="M39 57.5a18.5 18.5 0 1 0 0-37 18.5 18.5 0 0 0 0 37Z"/><path fill="%231A73E8" d="M39 53.652a14.65 14.65 0 0 0 13.536-20.26A14.653 14.653 0 1 0 39 53.653Z"/><defs><linearGradient id="a" x1="6.958" x2="71.034" y1="25.125" y2="25.125" gradientUnits="userSpaceOnUse"><stop stop-color="%23D93025"/><stop offset="1" stop-color="%23EA4335"/></linearGradient><linearGradient id="b" x1="43.003" x2="10.961" y1="73.684" y2="18.184" gradientUnits="userSpaceOnUse"><stop stop-color="%231E8E3E"/><stop offset="1" stop-color="%2334A853"/></linearGradient><linearGradient id="c" x1="33.598" x2="65.64" y1="76" y2="20.596" gradientUnits="userSpaceOnUse"><stop stop-color="%23FCC934"/><stop offset="1" stop-color="%23FBBC04"/></linearGradient></defs></svg>';



/***/ })

}]);