"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[3463],{

/***/ 93463:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ zora_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/zora.svg
var zora_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><g clip-path="url(%23a)"><path fill="url(%23b)" d="M.943 13.754c0 7.586 5.944 13.755 13.252 13.755 7.308 0 13.252-6.17 13.252-13.755C27.44 6.17 21.497 0 14.195 0 6.887 0 .943 6.17.943 13.754Z"/><path fill="url(%23c)" d="M.943 13.754c0 7.586 5.944 13.755 13.252 13.755 7.308 0 13.252-6.17 13.252-13.755C27.44 6.17 21.497 0 14.195 0 6.887 0 .943 6.17.943 13.754Z"/><path fill="url(%23d)" d="M.943 13.754c0 7.586 5.944 13.755 13.252 13.755 7.308 0 13.252-6.17 13.252-13.755C27.44 6.17 21.497 0 14.195 0 6.887 0 .943 6.17.943 13.754Z"/></g><defs><radialGradient id="b" cx="0" cy="0" r="1" gradientTransform="matrix(19.9547 0 0 20.7113 18.16 6.7)" gradientUnits="userSpaceOnUse"><stop offset=".005" stop-color="%23fff"/><stop offset=".458" stop-color="%23B7D8C8"/><stop offset=".656" stop-color="%236D9487"/><stop offset="1" stop-color="%234B4C3C"/></radialGradient><radialGradient id="c" cx="0" cy="0" r="1" gradientTransform="matrix(19.9547 0 0 20.7113 18.16 6.7)" gradientUnits="userSpaceOnUse"><stop offset=".005" stop-color="%23fff"/><stop offset=".458" stop-color="%23B5B4C6"/><stop offset=".656" stop-color="%239B8F8F"/><stop offset="1" stop-color="%234B4C3C"/></radialGradient><radialGradient id="d" cx="0" cy="0" r="1" gradientTransform="matrix(19.9547 0 0 20.7113 18.16 6.7)" gradientUnits="userSpaceOnUse"><stop offset=".156" stop-color="%23DCC8D0"/><stop offset=".302" stop-color="%2378C8CF"/><stop offset=".427" stop-color="%234D959E"/><stop offset=".557" stop-color="%23305EB9"/><stop offset=".797" stop-color="%23311F12"/><stop offset=".906" stop-color="%23684232"/><stop offset="1" stop-color="%232D1C13"/></radialGradient><clipPath id="a"><path fill="%23fff" d="M0 0h28v28H0z"/></clipPath></defs></svg>';



/***/ })

}]);