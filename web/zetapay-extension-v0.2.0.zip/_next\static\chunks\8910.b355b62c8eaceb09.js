"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[8910],{

/***/ 78910:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ zetachain_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/RainbowKitProvider/chainIcons/zetachain.svg
var zetachain_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none" viewBox="0 0 178 178"><circle cx="89" cy="89" r="89" fill="%23005741"/><path fill="%23fff" d="M112.109 108.673v12.02H62.523c.684-7.911 3.236-13.477 12.064-21.304l37.522-32.01v28.09h13.507V43.79H48.813v25.76H62.32V57.297h40.803L65.784 89.163l-.089.085c-15.648 13.854-16.892 25.036-16.892 38.211v6.751h76.818v-25.527h-13.507z"/></svg>';



/***/ })

}]);