"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[3140],{

/***/ 63140:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ refresh_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/Icons/refresh.svg
var refresh_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 48 48"><g clip-path="url(%23a)"><path fill="url(%23b)" d="M0 16c0-5.6 0-8.4 1.09-10.54a10 10 0 0 1 4.37-4.37C7.6 0 10.4 0 16 0h16c5.6 0 8.4 0 10.54 1.09a10 10 0 0 1 4.37 4.37C48 7.6 48 10.4 48 16v16c0 5.6 0 8.4-1.09 10.54a10.001 10.001 0 0 1-4.37 4.37C40.4 48 37.6 48 32 48H16c-5.6 0-8.4 0-10.54-1.09a10 10 0 0 1-4.37-4.37C0 40.4 0 37.6 0 32V16Z"/><path fill="%23000" fill-opacity=".08" fill-rule="evenodd" d="M1.133 9.513C1 11.131 1 13.183 1 16v16c0 2.817 0 4.87.133 6.486.131 1.606.387 2.695.848 3.6a9 9 0 0 0 3.933 3.933c.905.461 1.994.717 3.6.848C11.13 47 13.183 47 16 47h16c2.817 0 4.87 0 6.486-.133 1.606-.131 2.695-.387 3.6-.848a9 9 0 0 0 3.933-3.933c.461-.905.717-1.994.848-3.6C47 36.87 47 34.816 47 32V16c0-2.817 0-4.87-.133-6.487-.131-1.605-.387-2.694-.848-3.599a9 9 0 0 0-3.933-3.933c-.905-.461-1.994-.717-3.6-.848C36.87 1 34.816 1 32 1H16c-2.817 0-4.87 0-6.487.133-1.605.131-2.694.387-3.599.848a9 9 0 0 0-3.933 3.933c-.461.905-.717 1.994-.848 3.6ZM1.09 5.46C0 7.6 0 10.4 0 16v16c0 5.6 0 8.4 1.09 10.54a10 10 0 0 0 4.37 4.37C7.6 48 10.4 48 16 48h16c5.6 0 8.4 0 10.54-1.09a10.001 10.001 0 0 0 4.37-4.37C48 40.4 48 37.6 48 32V16c0-5.6 0-8.4-1.09-10.54a10 10 0 0 0-4.37-4.37C40.4 0 37.6 0 32 0H16C10.4 0 7.6 0 5.46 1.09a10 10 0 0 0-4.37 4.37Z" clip-rule="evenodd"/><path fill="%23000" fill-opacity=".12" d="M36.345 13.155a1.5 1.5 0 1 0-3 0v2.224c0 .627-.775.937-1.218.494a12.75 12.75 0 1 0 0 18.031 1.5 1.5 0 1 0-2.121-2.12 9.75 9.75 0 1 1 0-13.79c.61.61.172 1.616-.691 1.616H26.89a1.5 1.5 0 0 0 0 3h7.955a1.5 1.5 0 0 0 1.5-1.5v-7.955Z"/><path fill="%23fff" d="M36.345 12.155a1.5 1.5 0 1 0-3 0v2.224c0 .627-.775.937-1.218.494a12.75 12.75 0 1 0 0 18.031 1.5 1.5 0 1 0-2.121-2.12 9.75 9.75 0 1 1 0-13.79c.61.61.172 1.616-.691 1.616H26.89a1.5 1.5 0 0 0 0 3h7.955a1.5 1.5 0 0 0 1.5-1.5v-7.955Z"/></g><defs><linearGradient id="b" x1="24" x2="24" y1="0" y2="48" gradientUnits="userSpaceOnUse"><stop stop-color="%2359627A"/><stop offset="1" stop-color="%234A5266"/></linearGradient><clipPath id="a"><path fill="%23fff" d="M0 0h48v48H0z"/></clipPath></defs></svg>';



/***/ })

}]);