"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[3170],{

/***/ 63170:
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Opera_default; }
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ default auto */ // src/components/Icons/Opera.svg
var Opera_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 78 78"><linearGradient id="a" x2="1" gradientTransform="matrix(0 -54.944 -54.944 0 23.62 79.474)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="%23ff1b2d"/><stop offset=".3" stop-color="%23ff1b2d"/><stop offset=".614" stop-color="%23ff1b2d"/><stop offset="1" stop-color="%23a70014"/></linearGradient><linearGradient id="b" x2="1" gradientTransform="matrix(0 -48.595 -48.595 0 37.854 76.235)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="%239c0000"/><stop offset=".7" stop-color="%23ff4b4b"/><stop offset="1" stop-color="%23ff4b4b"/></linearGradient><path fill="url(%23a)" d="M28.346 80.398C12.691 80.398 0 67.707 0 52.052 0 36.85 11.968 24.443 26.996 23.739a28.244 28.244 0 0 1 20.241 7.18c-3.322-2.203-7.207-3.47-11.359-3.47-6.75 0-12.796 3.348-16.862 8.629-3.134 3.7-5.164 9.169-5.302 15.307v1.335c.138 6.137 2.168 11.608 5.302 15.307 4.066 5.28 10.112 8.63 16.862 8.63 4.152 0 8.038-1.269 11.36-3.474a28.239 28.239 0 0 1-18.785 7.215l-.108.001z" transform="matrix(1.3333 0 0 -1.3333 0 107.2)"/><path fill="url(%23b)" d="M19.016 68.025c2.601 3.07 5.96 4.923 9.631 4.923 8.252 0 14.941-9.356 14.941-20.897s-6.69-20.897-14.941-20.897c-3.67 0-7.03 1.85-9.63 4.922 4.066-5.281 10.11-8.63 16.862-8.63 4.152 0 8.036 1.268 11.359 3.472 5.802 5.19 9.455 12.735 9.455 21.133 0 8.397-3.653 15.94-9.453 21.13-3.324 2.206-7.209 3.473-11.361 3.473-6.75 0-12.796-3.348-16.862-8.63" transform="matrix(1.3333 0 0 -1.3333 0 107.2)"/></svg>';



/***/ })

}]);